<?php 
include "connection.php";

if(isset($_POST['addUsers'])){
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];

    // Insert Into Database 

    mysqli_query($con,"INSERT INTO crudoperation(name,address,phone,gender)VALUES('$name','$address','$phone','$gender')");

    echo "<script>
        alert('Data Inserted Successfully');
        location.assign('index.php')
    </script>";
}


// Delete Query

if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    // Query 
    mysqli_query($con,"DELETE FROM crudoperation WHERE id = '$id'");
    header('location:index.php');
}


?>